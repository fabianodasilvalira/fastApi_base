# app/core/__init__.py
# Este arquivo pode ser usado para expor configurações ou funções do core.

