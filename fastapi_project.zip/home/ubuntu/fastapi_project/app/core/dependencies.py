# app/core/dependencies.py
from typing import Generator, Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError
from sqlalchemy.orm import Session

from app.core import security
from app.models.user import User, UserRole
from app.schemas.token import TokenData # Será criado depois
from app.db.session import SessionLocal # Será criado depois
from app.services.user_service import user_service # Será criado depois

# Define o esquema de autenticação OAuth2
# tokenUrl deve apontar para a rota de login que ainda será criada (ex: "/login" ou "/auth/token")
reusable_oauth2 = OAuth2PasswordBearer(tokenUrl="/login")

def get_db() -> Generator:
    """Gera uma sessão de banco de dados para ser usada como dependência."""
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()

async def get_current_user(
    db: Session = Depends(get_db),
    token: str = Depends(reusable_oauth2)
) -> User:
    """Obtém o usuário atual a partir do token JWT.

    Decodifica o token, verifica se o usuário existe no banco de dados
    e retorna o objeto do usuário.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Não foi possível validar as credenciais",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = security.decode_token(token)
        if payload is None or payload.email is None:
            raise credentials_exception
        token_data = TokenData(email=payload.email) # Garante que o email está presente
    except JWTError:
        raise credentials_exception
    
    user = await user_service.get_user_by_email(db, email=token_data.email)
    if user is None:
        raise credentials_exception
    return user

async def get_current_active_user(
    current_user: User = Depends(get_current_user)
) -> User:
    """Verifica se o usuário atual está ativo (se houver campo de status no modelo User).
    
    Por enquanto, apenas retorna o usuário, mas pode ser estendido.
    """
    # if not current_user.is_active: # Exemplo se houvesse um campo is_active
    #     raise HTTPException(status_code=400, detail="Usuário inativo")
    return current_user

# Dependência para verificar se o usuário é Admin
def require_admin_user(
    current_user: User = Depends(get_current_active_user)
) -> User:
    """Verifica se o usuário atual tem o papel de Admin."""
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="O usuário não tem permissões de administrador"
        )
    return current_user

# Comentários em português:
# - `reusable_oauth2`: Instância do OAuth2PasswordBearer, que o FastAPI usa para extrair o token do header Authorization.
#   `tokenUrl` deve ser a rota onde o cliente obtém o token (ex: a rota de login).
# - `get_db`: Uma dependência que cria e gerencia uma sessão do SQLAlchemy para cada requisição.
# - `get_current_user`: Dependência principal para autenticação. Ela:
#   1. Extrai o token usando `reusable_oauth2`.
#   2. Decodifica o token usando `security.decode_token`.
#   3. Busca o usuário no banco de dados pelo email contido no token.
#   4. Levanta HTTPException se o token for inválido ou o usuário não for encontrado.
# - `get_current_active_user`: Uma dependência que pode ser usada para verificar se o usuário está ativo.
#   (Atualmente, apenas passa o usuário adiante, mas pode ser expandida se o modelo User tiver um campo `is_active`).
# - `require_admin_user`: Uma dependência que garante que o usuário autenticado tenha o papel `UserRole.ADMIN`.
#   Levanta HTTPException 403 (Forbidden) caso contrário.
# - As importações de `TokenData`, `SessionLocal` e `user_service` serão resolvidas quando esses módulos forem criados.

