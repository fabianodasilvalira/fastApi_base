# app/db/__init__.py
# Este arquivo pode ser usado para inicializar a conexão com o banco de dados
# ou para expor objetos importantes do módulo de banco de dados.

from .base_class import Base # Garante que Base seja conhecido ao importar models
from app.models.user import User # Importa os modelos para que Alembic os detecte

# Pode-se adicionar aqui a engine e a SessionLocal se não forem gerenciadas em outro lugar
# from .session import engine, SessionLocal # Exemplo

