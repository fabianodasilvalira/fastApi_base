# Este arquivo pode ficar vazio ou ser usado para expor os modelos
# from .user import User # Exemplo

