from sqlalchemy import Column, Integer, String, Enum as SQLAlchemyEnum, ForeignKey
from sqlalchemy.orm import relationship
from enum import Enum

from app.db.base_class import Base # Será criado depois

class UserRole(str, Enum):
    ADMIN = "admin"
    CLIENTE = "cliente"

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255), index=True)
    role = Column(SQLAlchemyEnum(UserRole), default=UserRole.CLIENTE, nullable=False)

    # Adicionar relacionamentos se necessário, por exemplo, com um perfil de usuário
    # profile = relationship("Profile", back_populates="user", uselist=False) # Exemplo

# Exemplo de um modelo de Perfil, se necessário
# class Profile(Base):
#     __tablename__ = "profiles"
#
#     id = Column(Integer, primary_key=True, index=True)
#     bio = Column(String(500), nullable=True)
#     user_id = Column(Integer, ForeignKey("users.id"))
#
#     user = relationship("User", back_populates="profile")

# Comentários em português:
# - O modelo `User` define a estrutura da tabela de usuários no banco de dados.
# - `id`: Chave primária auto-incrementável.
# - `email`: E-mail do usuário, deve ser único.
# - `hashed_password`: Senha do usuário armazenada de forma segura (hash).
# - `full_name`: Nome completo do usuário.
# - `role`: Define o papel do usuário (Admin ou Cliente), usando um Enum para garantir consistência.
#   Por padrão, um novo usuário é um Cliente.
# - A classe `UserRole` é um Enum que define os possíveis papéis de usuário.
# - A importação `from app.db.base_class import Base` será resolvida quando `base_class.py` for criado.
# - Comentários adicionais explicam cada campo e a lógica geral do modelo.

