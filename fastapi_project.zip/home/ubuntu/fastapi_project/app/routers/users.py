# app/routers/users.py
from typing import List, Any

from fastapi import APIRouter, Depends, HTTPException, status, Body
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession # Para uso com user_service assíncrono
# from sqlalchemy.orm import Session # Para uso com user_service síncrono

from app import schemas, models # models é usado para UserRole e User
from app.core import security
from app.core.dependencies import get_db, get_current_active_user, require_admin_user
from app.services.user_service import user_service

router = APIRouter()

@router.post("/login", response_model=schemas.Token, tags=["authentication"])
async def login_for_access_token(
    db: AsyncSession = Depends(get_db), # Mude para Session se user_service for síncrono
    form_data: OAuth2PasswordRequestForm = Depends()
) -> Any:
    """
    Realiza o login do usuário e retorna tokens de acesso e refresh.
    Utiliza OAuth2PasswordRequestForm para receber `username` (email) e `password`.
    """
    user = await user_service.get_user_by_email(db, email=form_data.username)
    if not user or not security.verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Email ou senha incorretos",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token = security.create_access_token(
        data={"sub": user.email, "user_id": user.id, "role": user.role.value}
    )
    refresh_token = security.create_refresh_token(
        data={"sub": user.email, "user_id": user.id, "role": user.role.value}
    )
    return {"access_token": access_token, "refresh_token": refresh_token, "token_type": "bearer"}

@router.post("/register", response_model=schemas.UserOut, status_code=status.HTTP_201_CREATED, tags=["users"])
async def register_new_user(
    *, # Força argumentos nomeados
    db: AsyncSession = Depends(get_db),
    user_in: schemas.UserCreate,
) -> Any:
    """
    Registra um novo usuário no sistema.
    Por padrão, o usuário será criado com o papel 'cliente',
    a menos que especificado de outra forma e permitido pela lógica (não implementado aqui).
    """
    existing_user = await user_service.get_user_by_email(db, email=user_in.email)
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Um usuário com este email já existe no sistema.",
        )
    user = await user_service.create_user(db=db, user_in=user_in)
    return user

@router.get("/me", response_model=schemas.UserOut, tags=["users"])
async def read_current_user(
    current_user: models.User = Depends(get_current_active_user)
) -> Any:
    """
    Retorna os dados do usuário autenticado.
    """
    return current_user

@router.get("/{user_id}", response_model=schemas.UserOut, dependencies=[Depends(require_admin_user)], tags=["users"])
async def read_user_by_id(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    # current_user: models.User = Depends(require_admin_user) # Já injetado pela dependência no decorator
) -> Any:
    """
    Retorna os dados de um usuário específico pelo ID (somente Admin).
    """
    user = await user_service.get_user_by_id(db, user_id=user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado.",
        )
    return user

@router.put("/{user_id}", response_model=schemas.UserOut, dependencies=[Depends(require_admin_user)], tags=["users"])
async def update_user_by_id(
    user_id: int,
    user_in: schemas.UserUpdate,
    db: AsyncSession = Depends(get_db),
    # current_user: models.User = Depends(require_admin_user)
) -> Any:
    """
    Atualiza os dados de um usuário específico pelo ID (somente Admin).
    """
    db_user = await user_service.get_user_by_id(db, user_id=user_id)
    if not db_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado para atualização.",
        )
    updated_user = await user_service.update_user(db=db, db_user=db_user, user_in=user_in)
    return updated_user

@router.get("/", response_model=List[schemas.UserOut], dependencies=[Depends(require_admin_user)], tags=["users"])
async def read_all_users(
    db: AsyncSession = Depends(get_db),
    skip: int = 0,
    limit: int = 100,
    # current_user: models.User = Depends(require_admin_user)
) -> Any:
    """
    Retorna uma lista de todos os usuários (somente Admin).
    """
    users = await user_service.get_users(db, skip=skip, limit=limit)
    return users

# Comentários em português:
# - O roteador `router` é uma instância de `APIRouter`.
# - `/login`: Rota para autenticação. Recebe email (como `username`) e senha via `OAuth2PasswordRequestForm`.
#   Verifica as credenciais e retorna um `access_token` e `refresh_token`.
# - `/register`: Rota para criar um novo usuário. Valida se o email já existe.
# - `/me`: Rota protegida que retorna os dados do usuário atualmente autenticado.
#   Usa a dependência `get_current_active_user`.
# - `/{user_id}` (GET): Rota protegida para Admin, retorna dados de um usuário específico.
# - `/{user_id}` (PUT): Rota protegida para Admin, atualiza dados de um usuário específico.
# - `/` (GET): Rota protegida para Admin, retorna uma lista de todos os usuários com paginação.
# - As dependências `get_db`, `get_current_active_user`, e `require_admin_user` são usadas para
#   gerenciar sessões de banco de dados e controle de acesso.
# - `AsyncSession` é usado para operações de banco de dados assíncronas. Se o `user_service` e a configuração do DB
#   forem síncronos, deve-se usar `Session` e remover `async/await` das chamadas ao serviço e do DB.
# - As tags são usadas para agrupar as rotas na documentação da API (Swagger/OpenAPI).

