# app/schemas/user.py
from typing import Optional
from enum import Enum

from pydantic import BaseModel, EmailStr, Field

# Reutiliza o Enum de UserRole definido nos modelos para consistência
# Se UserRole não estiver acessível diretamente aqui (import circular ou organização),
# pode-se redefinir um Enum similar aqui para validação de schema.
# from app.models.user import UserRole # Idealmente, importar se possível

class UserRole(str, Enum):
    ADMIN = "admin"
    CLIENTE = "cliente"

# Propriedades básicas do usuário, compartilhadas por outros esquemas
class UserBase(BaseModel):
    email: EmailStr = Field(..., example="usuario@example.com")
    full_name: Optional[str] = Field(None, example="Nome Completo do Usuário")

# Propriedades para criar um novo usuário
class UserCreate(UserBase):
    password: str = Field(..., min_length=8, example="senhaSuperF0rte")
    role: UserRole = Field(UserRole.CLIENTE, example="cliente") # Default para cliente

# Propriedades para atualizar um usuário (Admin pode atualizar mais campos)
class UserUpdate(BaseModel):
    email: Optional[EmailStr] = Field(None, example="novo_email@example.com")
    full_name: Optional[str] = Field(None, example="Novo Nome Completo")
    password: Optional[str] = Field(None, min_length=8, example="novaSenhaSuperF0rte")
    role: Optional[UserRole] = Field(None, example="admin")

# Propriedades armazenadas no DB, mas não necessariamente retornadas sempre
class UserInDBBase(UserBase):
    id: int
    role: UserRole

    class Config:
        orm_mode = True # Permite que o Pydantic leia dados de objetos ORM

# Propriedades adicionais para retornar ao cliente (sem o hashed_password)
class UserOut(UserInDBBase):
    pass # Herda todos os campos de UserInDBBase

# Comentários em português:
# - `UserRole`: Enum para os papéis de usuário, espelhando o que está no modelo SQLAlchemy.
# - `UserBase`: Contém os campos comuns a todos os esquemas de usuário (email, nome completo).
#   `EmailStr` do Pydantic valida o formato do e-mail.
# - `UserCreate`: Usado para criar um novo usuário. Requer senha e define um papel (padrão Cliente).
#   `min_length=8` para a senha é um exemplo de validação.
# - `UserUpdate`: Usado para atualizar um usuário. Todos os campos são opcionais.
# - `UserInDBBase`: Representa como o usuário é armazenado no banco de dados, incluindo `id` e `role`.
#   `Config.orm_mode = True` (ou `from_attributes = True` em Pydantic V2) permite que o esquema seja populado a partir de um modelo SQLAlchemy.
# - `UserOut`: Esquema para retornar dados do usuário ao cliente. Exclui campos sensíveis como `hashed_password` (que não está em `UserInDBBase`).
#   Neste caso, é idêntico a `UserInDBBase`, mas poderia ser customizado para omitir outros campos se necessário.

