# app/services/__init__.py
# Este arquivo pode ser usado para expor os serviços.

from .user_service import user_service

