# app/services/user_service.py
from typing import Optional, List

from sqlalchemy.orm import Session
from sqlalchemy.future import select # Para SQLAlchemy 1.4+

from app.models.user import User, UserRole
from app.schemas.user import UserCreate, UserUpdate
from app.core.security import get_password_hash

class UserService:
    async def get_user_by_id(self, db: Session, user_id: int) -> Optional[User]:
        """Busca um usuário pelo ID."""
        result = await db.execute(select(User).filter(User.id == user_id))
        return result.scalars().first()

    async def get_user_by_email(self, db: Session, email: str) -> Optional[User]:
        """Busca um usuário pelo email."""
        result = await db.execute(select(User).filter(User.email == email))
        return result.scalars().first()

    async def get_users(
        self, db: Session, skip: int = 0, limit: int = 100
    ) -> List[User]:
        """Busca uma lista de usuários com paginação."""
        result = await db.execute(select(User).offset(skip).limit(limit))
        return result.scalars().all()

    async def create_user(self, db: Session, user_in: UserCreate) -> User:
        """Cria um novo usuário."""
        hashed_password = get_password_hash(user_in.password)
        db_user = User(
            email=user_in.email,
            hashed_password=hashed_password,
            full_name=user_in.full_name,
            role=user_in.role  # O schema UserCreate já define um default
        )
        db.add(db_user)
        await db.commit()
        await db.refresh(db_user)
        return db_user

    async def update_user(
        self, db: Session, db_user: User, user_in: UserUpdate
    ) -> User:
        """Atualiza um usuário existente."""
        update_data = user_in.model_dump(exclude_unset=True) # Pydantic v2
        # update_data = user_in.dict(exclude_unset=True) # Pydantic v1

        if "password" in update_data and update_data["password"]:
            hashed_password = get_password_hash(update_data["password"])
            db_user.hashed_password = hashed_password
            del update_data["password"] # Remove para não tentar atribuir diretamente

        for field, value in update_data.items():
            setattr(db_user, field, value)
        
        db.add(db_user)
        await db.commit()
        await db.refresh(db_user)
        return db_user

    async def delete_user(self, db: Session, user_id: int) -> Optional[User]:
        """Deleta um usuário pelo ID."""
        db_user = await self.get_user_by_id(db, user_id=user_id)
        if db_user:
            await db.delete(db_user)
            await db.commit()
        return db_user

# Instância do serviço para ser importada e usada em outros lugares
user_service = UserService()

# Comentários em português:
# - Esta classe `UserService` encapsula a lógica de negócio relacionada aos usuários.
# - Métodos assíncronos (`async def`) são usados para interagir com o banco de dados de forma não bloqueante,
#   assumindo que a engine do SQLAlchemy e o driver do banco de dados suportam operações assíncronas (ex: `asyncpg` para PostgreSQL, `aiomysql` para MySQL).
#   Se estiver usando uma configuração síncrona, remova `async` e `await`.
# - `get_user_by_id`, `get_user_by_email`, `get_users`: Métodos para buscar usuários.
# - `create_user`: Cria um novo usuário, hasheando a senha antes de salvar.
# - `update_user`: Atualiza um usuário. Se a senha for fornecida, ela é hasheada.
#   `user_in.model_dump(exclude_unset=True)` (Pydantic V2) ou `user_in.dict(exclude_unset=True)` (Pydantic V1)
#   é usado para obter apenas os campos que foram realmente enviados na requisição de atualização.
# - `delete_user`: Deleta um usuário.
# - `user_service`: Uma instância da classe é criada para fácil importação e uso nas rotas.
# - As operações de banco de dados (`db.execute`, `db.add`, `db.commit`, `db.refresh`, `db.delete`)
#   devem ser `await`ed se a sessão `db` for assíncrona.

